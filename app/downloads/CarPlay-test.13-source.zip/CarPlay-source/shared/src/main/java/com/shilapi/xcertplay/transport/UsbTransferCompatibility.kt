package com.shilapi.xcertplay.transport

import android.os.Build

/** Pre-P async requests reject buffers over 16 KiB; bulkTransfer truncates at the same limit. */
internal fun usbTransferChunkBytes(preferredBytes: Int): Int =
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) minOf(preferredBytes, 16_384)
    else preferredBytes
