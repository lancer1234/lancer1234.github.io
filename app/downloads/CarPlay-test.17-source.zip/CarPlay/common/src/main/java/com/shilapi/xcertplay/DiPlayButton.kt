// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.animation.PathInterpolator
import android.os.Build
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.widget.Button
import androidx.core.graphics.ColorUtils

internal enum class DiPlayButtonKind { PRIMARY, SECONDARY, DANGER, TONAL_DANGER }

/**
 * Button for views built in code outside `DiPlayActivity`, whose own `button()` stays private.
 * The corner radius follows the control height, as in `DiPlayActivity.buttonShape`.
 */
internal class DiPlayButton(context: Context) : Button(context) {
    private var kind = DiPlayButtonKind.SECONDARY
    private var palette: DiPlayPalette? = null
    private var overlay = false

    init {
        isAllCaps = false
        stateListAnimator = null
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** [overlay] picks the in-car menu colours instead of the app chrome colours. */
    fun style(kind: DiPlayButtonKind, palette: DiPlayPalette, overlay: Boolean) {
        this.kind = kind
        this.palette = palette
        this.overlay = overlay
        repaint()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (h != oldh) repaint()
    }

    private fun repaint() {
        val palette = palette ?: return
        val density = resources.displayMetrics.density
        val fill: Int
        val text: Int
        val stroke: Int
        when (kind) {
            DiPlayButtonKind.PRIMARY -> {
                fill = if (overlay) palette.overlayAccent else palette.accent
                text = if (overlay) palette.overlayOnAccent else palette.onAccent
                stroke = fill
            }
            DiPlayButtonKind.SECONDARY -> {
                fill = if (overlay) palette.overlayTrackOff else palette.button
                text = if (overlay) palette.overlayPrimaryText else palette.primaryText
                stroke = if (overlay) fill else palette.outline
            }
            DiPlayButtonKind.DANGER -> {
                fill = palette.overlayDanger
                text = Color.WHITE
                stroke = fill
            }
            DiPlayButtonKind.TONAL_DANGER -> {
                val surface = if (overlay) palette.overlayBackground else palette.surface
                fill = ColorUtils.blendARGB(surface, palette.overlayDanger, 0.16f)
                text = if (ColorUtils.calculateLuminance(surface) < 0.5)
                    ColorUtils.blendARGB(palette.overlayDanger, Color.WHITE, 0.40f)
                else palette.overlayDanger
                stroke = ColorUtils.blendARGB(surface, palette.overlayDanger, 0.48f)
            }
        }
        val radius = minOf(24f * density, (if (height > 0) height else minHeight) * 20f / 56)
        setTextColor(text)
        background = RippleDrawable(
            ColorStateList.valueOf(palette.ripple),
            GradientDrawable().apply {
                setColor(fill)
                cornerRadius = radius
                setStroke((1 * density).toInt().coerceAtLeast(1), stroke)
            },
            null,
        )
        // Remote and D-pad users need to see where they are; touch mode never shows it.
        foreground = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = radius
                setStroke((3 * density).toInt(), palette.focusRing)
            })
        }
    }
    private var handlingTouch = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        handlingTouch = true
        try {
            return super.onTouchEvent(event)
        } finally {
            handlingTouch = false
        }
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (!changed) return
        animate().cancel()
        // Keyboard/remote actions stay immediate; honour Android's animation-off setting.
        if (handlingTouch && isEnabled && (Build.VERSION.SDK_INT < 26 || ValueAnimator.areAnimatorsEnabled())) {
            val scale = if (pressed) 0.97f else 1f
            animate().scaleX(scale).scaleY(scale).setDuration(120)
                .setInterpolator(PathInterpolator(0.23f, 1f, 0.32f, 1f)).start()
        } else {
            scaleX = 1f
            scaleY = 1f
        }
    }

    override fun onDetachedFromWindow() {
        animate().cancel()
        scaleX = 1f
        scaleY = 1f
        super.onDetachedFromWindow()
    }
}
