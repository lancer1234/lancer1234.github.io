package com.shilapi.xcertplay

import android.content.res.Resources
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.shilapi.xcertplay.host.R
import com.shilapi.xcertplay.hud.BydOutputSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.annotation.RealObject
import org.robolectric.shadow.api.Shadow
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter

/** Common's normal resources enable vehicle integration; the shipped mobile overlay disables it. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [27, 33], qualifiers = "en-w700dp-h500dp-land",
    shadows = [GenericReceiverResources::class])
class GenericReceiverIntegrationTest {
    @Test fun receiverControlsRemainReachableWithoutVehicleIntegration() {
        val controller = Robolectric.buildActivity(DiPlayActivity::class.java,
            Intent().putExtra("page", "settings")).setup()
        val screen = controller.get()
        try {
            assertFalse(BydOutputSettings.integrationEnabled(screen))
            open(screen, SettingsCategory.AUDIO)
            assertTrue(labels(screen).contains(screen.getString(R.string.carplay_microphone)))
            assertTrue(labels(screen).any { it.startsWith(screen.getString(R.string.carplay_microphone_volume)) })
            open(screen, SettingsCategory.DISPLAY)
            assertTrue(labels(screen).contains(screen.getString(R.string.carplay_landscape_lock)))
            open(screen, SettingsCategory.ADVANCED)
            assertTrue(labels(screen).contains(screen.getString(R.string.standalone_video_toggle)))
            assertFalse(labels(screen).contains(screen.getString(R.string.advanced_vehicle_data)))
        } finally { controller.pause().stop().destroy() }
    }

    @Test fun customBuildUpdateEntryUsesOurDownloadPage() {
        val controller = Robolectric.buildActivity(DiPlayActivity::class.java,
            Intent().putExtra("page", "settings")).setup()
        val screen = controller.get()
        try {
            open(screen, SettingsCategory.ABOUT)
            descendants(screen.window.decorView).filterIsInstance<TextView>()
                .single { it.text.toString() == screen.getString(R.string.update_check) }.performClick()
            assertEquals("https://makotolab.tw/app/", shadowOf(screen).nextStartedActivity.dataString)
        } finally { controller.pause().stop().destroy() }
    }

    private fun open(screen: DiPlayActivity, category: SettingsCategory) {
        ReflectionHelpers.callInstanceMethod<Unit>(screen, "openSettingsCategory",
            ClassParameter.from(SettingsCategory::class.java, category))
    }
    private fun labels(screen: DiPlayActivity) = descendants(screen.window.decorView)
        .filterIsInstance<TextView>().map { it.text.toString() }
    private fun descendants(view: View): List<View> = listOf(view) +
        if (view is ViewGroup) (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
}

@Implements(Resources::class)
class GenericReceiverResources {
    @RealObject private lateinit var resources: Resources
    @Implementation fun getBoolean(id: Int): Boolean =
        if (id == com.shilapi.xcertplay.shared.R.bool.config_byd_integration) false
        else Shadow.directlyOn(resources, Resources::class.java, "getBoolean",
            ClassParameter.from(Int::class.javaPrimitiveType, id))
}
