package com.shilapi.xcertplay.backup

import com.shilapi.xcertplay.CarPlayAdvancedSettings
import com.shilapi.xcertplay.CarPlayVideoSettings
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [27], manifest = Config.NONE)
class ReceiverSettingsBackupTest {
    @Test fun receiverSettingsRoundTripWithoutImportingUnknownPairingFields() {
        val app = RuntimeEnvironment.getApplication()
        val advanced = app.getSharedPreferences("diplay_carplay_advanced", 0)
        val video = app.getSharedPreferences("diplay_video", 0)
        try {
            advanced.edit().clear().commit(); video.edit().clear().commit()
            CarPlayAdvancedSettings.setLandscapeLocked(app, true)
            CarPlayAdvancedSettings.setDisplayOnly(app, true)
            CarPlayAdvancedSettings.setMicrophoneEnabled(app, false)
            CarPlayAdvancedSettings.setSpeechMicrophoneCompatibility(app, true)
            CarPlayAdvancedSettings.setMicrophoneVolumeLevel(app, 2)
            CarPlayVideoSettings.setStandaloneEnabled(app, true)
            CarPlayVideoSettings.setVolumeBoost(app, 1200)
            val document = JSONObject(SettingsBackupCodec.export(app, "test").toString(Charsets.UTF_8))
            document.getJSONObject("settings").getJSONObject("diplay_carplay_advanced")
                .put("pairing.injected", "unexpected")
            advanced.edit().clear().commit(); video.edit().clear().commit()
            val outcome = SettingsBackupCodec.import(app, document.toString().toByteArray())
            assertFalse(outcome.invalid)
            assertEquals(1, outcome.skipped)
            assertTrue(CarPlayAdvancedSettings.landscapeLocked(app))
            assertTrue(CarPlayAdvancedSettings.displayOnly(app))
            assertFalse(CarPlayAdvancedSettings.microphoneEnabled(app))
            assertTrue(CarPlayAdvancedSettings.speechMicrophoneCompatibility(app))
            assertEquals(2, CarPlayAdvancedSettings.microphoneVolumeLevel(app))
            assertTrue(CarPlayVideoSettings.standaloneEnabled(app))
            assertEquals(1200, CarPlayVideoSettings.volumeBoost(app))
            assertFalse(advanced.contains("pairing.injected"))
        } finally { advanced.edit().clear().commit(); video.edit().clear().commit() }
    }
}
