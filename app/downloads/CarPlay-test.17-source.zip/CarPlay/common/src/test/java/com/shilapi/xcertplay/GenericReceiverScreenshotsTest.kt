package com.shilapi.xcertplay

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.shilapi.xcertplay.host.R
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], shadows = [GenericReceiverResources::class])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class GenericReceiverScreenshotsTest {
    @Test fun customControlsFitCompactFullAndRtlWithLargeFonts() {
        for ((name, qualifiers, font) in listOf(
            Triple("compact-zh-TW", "zh-rTW-w360dp-h800dp-xhdpi", 1.3f),
            Triple("full-zh-TW", "zh-rTW-w1000dp-h700dp-land-xhdpi", 1.5f),
            Triple("compact-ar-rtl", "ar-ldrtl-w360dp-h800dp-xhdpi", 1.3f),
        )) {
            RuntimeEnvironment.setQualifiers(qualifiers)
            RuntimeEnvironment.setFontScale(font)
            val controller = Robolectric.buildActivity(DiPlayActivity::class.java,
                Intent().putExtra("page", "settings")).setup()
            val screen = controller.get()
            try {
                for ((category, title, suffix) in listOf(
                    Triple(SettingsCategory.AUDIO, R.string.carplay_microphone_volume, "microphone"),
                    Triple(SettingsCategory.DISPLAY, R.string.carplay_landscape_lock, "orientation"),
                )) {
                    ReflectionHelpers.callInstanceMethod<Unit>(screen, "openSettingsCategory",
                        ClassParameter.from(SettingsCategory::class.java, category))
                    val root = screen.findViewById<ViewGroup>(android.R.id.content).getChildAt(0)
                    fun layout() {
                        val metrics = screen.resources.displayMetrics
                        val config = screen.resources.configuration
                        val width = (config.screenWidthDp * metrics.density).toInt()
                        val height = (config.screenHeightDp * metrics.density).toInt()
                        root.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
                        root.layout(0, 0, width, height)
                    }
                    layout()
                    val control = descendants(root).filterIsInstance<TextView>()
                        .first { it.text.toString().startsWith(screen.getString(title)) }
                    control.requestRectangleOnScreen(Rect(0, 0, control.width, control.height), true)
                    layout()
                    assertTrue("Receiver control must remain visible: $name/$suffix",
                        control.getGlobalVisibleRect(Rect()))
                    val textHeight = control.layout.height + control.compoundPaddingTop + control.compoundPaddingBottom
                    assertTrue("Large-font control text must not be clipped: $name/$suffix", control.height >= textHeight)
                    val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888)
                    try {
                        root.draw(Canvas(bitmap))
                        val file = File("build/reports/generic-receiver-ui/$name-$suffix.png")
                        file.parentFile.mkdirs()
                        file.outputStream().use { assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
                    } finally { bitmap.recycle() }
                }
            } finally { controller.pause().stop().destroy() }
        }
    }
    private fun descendants(view: View): List<View> = listOf(view) +
        if (view is ViewGroup) (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
}
