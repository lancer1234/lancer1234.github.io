package com.shilapi.xcertplay;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.shilapi.xcertplay.media.NativeSoftwareOpusEncoder;
import org.concentus.OpusDecoder;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.List;
import static org.junit.Assert.*;

/** Exercise the packaged Android JNI library with synthetic PCM; no microphone or phone audio is captured. */
@RunWith(AndroidJUnit4.class)
public class NativeMicrophoneDeviceTest {
    @Test public void nativePacketsDecodeAtTheExpectedDurationAndPitch() throws Exception {
        for (int bitrate : new int[] {24000, 48000}) {
            NativeSoftwareOpusEncoder encoder = new NativeSoftwareOpusEncoder(bitrate);
            try {
                assertTrue("Packaged native Opus unavailable", encoder.getAvailable());
                assertEquals("native-libopus", encoder.getImplementation());
                assertTrue(encoder.encode(new byte[7]).isEmpty());
                OpusDecoder decoder = new OpusDecoder(48000, 1);
                int crossings = 0; short previous = 0; long energy = 0;
                for (int f=0; f<40; f++) {
                    byte[] pcm = new byte[1920];
                    for (int i=0; i<960; i++) {
                        short value = (short)(9000 * Math.sin(2 * Math.PI * 523.25 * (f*960+i) / 48000));
                        pcm[2*i] = (byte)value; pcm[2*i+1] = (byte)(value >> 8);
                    }
                    List<byte[]> packets = encoder.encode(pcm);
                    assertEquals("Missing native packet", 1, packets.size());
                    byte[] packet = packets.get(0); short[] output = new short[960];
                    assertEquals(960, decoder.decode(packet, 0, packet.length, output, 0, 960, false));
                    for (short sample : output) {
                        energy += (long)sample*sample;
                        if (f>=2 && previous<=0 && sample>0) crossings++;
                        previous = sample;
                    }
                }
                assertTrue("Native PCM was silent", energy > 1000000);
                assertTrue("Native PCM pitch changed: "+crossings, crossings>=350 && crossings<=450);
            } finally { encoder.close(); }
            encoder.close();
            assertFalse(encoder.getAvailable());
            assertTrue(encoder.encode(new byte[1920]).isEmpty());
        }
    }
}
