# CarPlay test.16 upstream integration

Upstream base: v0.2.12 (`22d2aac`). Integrated release: v0.2.15 (`b940efe`).
The reviewed main (`9e244d9`) adds only issue-template edits after that release.
Local pre-merge source: test.15, versionCode 54. Candidate: 0.2.15-carplay-test.16, versionCode 55.

## Preservation

- Original working directory `work/DiPlay-main` was left untouched.
- Source branch `stable/pre-upstream-test15-20261009` preserves `0ccbfa9` before the merge.
- Website branch `stable/carplay-before-upstream-20261009` preserves published test.13 at `bad0a77` and is pushed to the website repository.
- test.13 APK, checksum, source archive and direct download URL must remain available. Any test.16 download is an additional test release.
- Runtime authentication is provisioned explicitly from a local directory. No identity, signing key or local SDK configuration is included in source archives.

## Integrated changes

| Area | Result |
| --- | --- |
| Siri | Upstream observed Siri Opus RTP timestamp correction; capture/encoding remains at its negotiated rate. Existing general-input compatibility, PCM gain, diagnostics and vendored Opus retained. |
| Audio | Buffer progress accounting, rebuffer recovery, audio focus and optional call echo cancellation/voice filtering. Call processing is opt-in and does not process Siri input. |
| Android 8.1 | Upstream API 25 guards and compatibility helpers, legacy P2P and USB completion handling. Retained pre-Android 9 16 KiB limits for asynchronous reads and bulk writes; modern vendor rejection fallback retained. |
| Wireless | Current address selection, P2P startup recovery, Bluetooth duplex notification and optional car-hotspot capability improvements. No Mac network or sharing settings changed. |
| Video display | Decoder operating-rate fallback, TCP touch latency improvement, SurfaceView fallback, optional smooth video and rotation/view areas. Experimental modes default off. |
| Transport crypto | Platform ChaCha20-Poly1305 with compatibility fallback. This decrypts transport data and does not implement FairPlay playback authorization. |
| Settings | Categorized/searchable adaptive UI, appearance and interface size, reconnect notices. Receiver display settings live in Display; microphone settings in Audio; experimental audio/video settings in Advanced. |
| Local video | iPhone internet proxy, session data source, HLS steering compatibility, DRM diagnostics, remembered video gain retained. |
| Product identity | CarPlay brand, Traditional Chinese, no OEM CarPlay icon; generic mobile build keeps BYD integration disabled. Required open-source attribution remains in the license dialog/source. |
| Updates | About opens the MAKOTO LAB download page. It does not download an upstream APK that would replace this custom build. |

## Validation and limits

Full CI command from AGENTS.md: passed. Shared: 1,023 test cases (one existing skipped case), Common: 1,009; zero failures. Mobile, home and map-host lint/build checks passed. API 27 receiver settings and legacy USB coverage are included. Standalone APK and connected-device video verification are recorded with the release artifacts.
API 27 automated USB and receiver-settings regressions exercise Android 8.1 behavior. Actual vehicle hardware still requires a connection test; API level alone does not guarantee the vendor Bluetooth stack or USB ports work.

Apple TV protected-film playback is unresolved. Prior tests played only the opening seconds. This merge does not claim to fix FairPlay or make YouTube offer an AirPlay video stream. A successful synthetic HLS/MP4 playback check does not establish DRM compatibility.
