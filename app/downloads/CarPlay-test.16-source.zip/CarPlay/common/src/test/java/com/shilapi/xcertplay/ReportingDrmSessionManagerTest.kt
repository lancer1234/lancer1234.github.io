package com.shilapi.xcertplay

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.DrmInitData
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.drm.DefaultDrmSessionManagerProvider
import androidx.media3.exoplayer.drm.DrmSession
import androidx.media3.exoplayer.drm.DrmSessionManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(UnstableApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class ReportingDrmSessionManagerTest {
    private val errors = mutableListOf<Int>()
    private fun manager(): ReportingDrmSessionManager {
        val delegate = DefaultDrmSessionManagerProvider().get(MediaItem.fromUri("https://example.test/movie.m3u8"))
        return ReportingDrmSessionManager(delegate) { _, error -> errors.add(error.errorCode) }
    }

    @Test fun clearIntroRemainsPlayableUntilProtectedSamplesRequireASession() {
        val manager = manager()
        val clear = format(MimeTypes.VIDEO_H264, false)
        assertNull(manager.acquireSession(null, clear))
        assertEquals(C.CRYPTO_TYPE_NONE, manager.getCryptoType(clear))
        assertTrue(errors.isEmpty())
        val protected = format(MimeTypes.VIDEO_H264, true)
        val session = manager.acquireSession(null, protected)
        assertEquals(DrmSession.STATE_ERROR, session!!.state)
        assertEquals(listOf(PlaybackException.ERROR_CODE_DRM_SCHEME_UNSUPPORTED), errors)
        assertEquals(C.CRYPTO_TYPE_UNSUPPORTED, manager.getCryptoType(protected))
    }

    @Test fun protectedAudioFailureAlsoReportsInsteadOfLeavingVideoBuffering() {
        assertEquals(DrmSession.STATE_ERROR, manager().acquireSession(null, format(MimeTypes.AUDIO_AAC, true))!!.state)
        assertEquals(listOf(PlaybackException.ERROR_CODE_DRM_SCHEME_UNSUPPORTED), errors)
    }

    @Test fun preacquiringProtectedFormatDoesNotRejectClearIntro() {
        val reference = manager().preacquireSession(null, format(MimeTypes.VIDEO_H264, true))
        reference.release()
        assertTrue(errors.isEmpty())
    }

    @Test fun clearAudioDoesNotReportDrmFailure() {
        assertNull(manager().acquireSession(null, format(MimeTypes.AUDIO_AAC, false)))
        assertTrue(errors.isEmpty())
    }

    @Test fun delegateSessionIsReturnedUnchanged() {
        val protected = format(MimeTypes.VIDEO_H264, true)
        val expected = DrmSessionManager.DRM_UNSUPPORTED.acquireSession(null, protected)
        val delegate = object : DrmSessionManager by DrmSessionManager.DRM_UNSUPPORTED {
            override fun acquireSession(dispatcher: androidx.media3.exoplayer.drm.DrmSessionEventListener.EventDispatcher?,
                format: Format): DrmSession? = expected
        }
        val manager = ReportingDrmSessionManager(delegate) { _, error -> errors.add(error.errorCode) }
        assertSame(expected, manager.acquireSession(null, protected))
    }

    private fun format(mime: String, protected: Boolean) = Format.Builder().setSampleMimeType(mime).apply {
        if (protected) setDrmInitData(DrmInitData("cbcs",
            DrmInitData.SchemeData(C.WIDEVINE_UUID, MimeTypes.VIDEO_MP4, byteArrayOf(1))))
    }.build()
}
