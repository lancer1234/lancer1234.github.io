package com.shilapi.xcertplay

import android.app.Activity
import org.robolectric.Robolectric
import android.os.Looper
import org.robolectric.Shadows.shadowOf
import android.provider.Settings
import android.view.MotionEvent
import org.robolectric.RuntimeEnvironment
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33])
class DiPlayButtonTest {
    private fun touch(button: DiPlayButton, action: Int) {
        val event = MotionEvent.obtain(0L, 0L, action, 20f, 20f, 0)
        try { button.onTouchEvent(event) } finally { event.recycle() }
    }

    @Test fun cancellingATouchDoesNotClickOrLeavePressedState() {
        val button = DiPlayButton(RuntimeEnvironment.getApplication())
        var clicks = 0
        button.setOnClickListener { clicks++ }
        button.layout(0, 0, 200, 100)
        touch(button, MotionEvent.ACTION_DOWN)
        assertTrue(button.isPressed)
        touch(button, MotionEvent.ACTION_CANCEL)
        assertFalse(button.isPressed)
        assertEquals(0, clicks)
    }

    @Test fun keyboardPressDoesNotScaleTheButton() {
        val button = DiPlayButton(RuntimeEnvironment.getApplication())
        button.isPressed = true
        assertEquals(1f, button.scaleX, 0f)
        assertEquals(1f, button.scaleY, 0f)
        button.isPressed = false
    }

    @Test fun disablingAnimationRetainsTouchAndClickBehaviour() {
        val context = RuntimeEnvironment.getApplication()
        val previous = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        Settings.Global.putFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 0f)
        try {
            val controller = Robolectric.buildActivity(Activity::class.java).setup().visible()
            val button = DiPlayButton(controller.get())
            controller.get().setContentView(button)
            var clicks = 0
            button.setOnClickListener { clicks++ }
            button.layout(0, 0, 200, 100)
            touch(button, MotionEvent.ACTION_DOWN)
            assertEquals(1f, button.scaleX, 0f)
            touch(button, MotionEvent.ACTION_UP)
            shadowOf(Looper.getMainLooper()).idle()
            assertEquals(1, clicks)
            controller.pause().stop().destroy()
        } finally {
            Settings.Global.putFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, previous)
        }
    }
}
