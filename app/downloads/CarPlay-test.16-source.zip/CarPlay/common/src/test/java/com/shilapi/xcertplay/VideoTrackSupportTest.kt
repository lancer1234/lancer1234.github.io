package com.shilapi.xcertplay

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.DrmInitData
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(UnstableApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
class VideoTrackSupportTest {
    @Test fun protectedVideoWithOnlyTextSelectedIsRejected() {
        assertTrue(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H264, true, C.FORMAT_UNSUPPORTED_DRM),
            group(MimeTypes.TEXT_VTT, false, C.FORMAT_HANDLED, selected = true),
        ))))
    }

    @Test fun protectedVideoWithClearAudioIsStillRejected() {
        assertTrue(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H264, true, C.FORMAT_UNSUPPORTED_DRM),
            group(MimeTypes.AUDIO_AAC, false, C.FORMAT_HANDLED, selected = true),
        ))))
    }

    @Test fun emptyOrAudioOnlyTracksAreNotRejected() {
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks.EMPTY))
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.AUDIO_AAC, false, C.FORMAT_HANDLED, selected = true),
        ))))
    }

    @Test fun playableClearVariantKeepsMovieAvailable() {
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H264, true, C.FORMAT_UNSUPPORTED_DRM),
            group(MimeTypes.VIDEO_H264, false, C.FORMAT_HANDLED, selected = true),
        ))))
    }

    @Test fun codecFailureIsNotMisreportedAsDrm() {
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H265, true, C.FORMAT_UNSUPPORTED_SUBTYPE),
        ))))
    }

    @Test fun supportedProtectedVideoIsNotRejected() {
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H264, true, C.FORMAT_HANDLED, selected = true),
        ))))
    }

    @Test fun mixedAvcDrmAndUnsupportedHevcRenditionsStillReportDrm() {
        val drm = DrmInitData("cbcs", DrmInitData.SchemeData(C.WIDEVINE_UUID, MimeTypes.VIDEO_MP4, byteArrayOf(1)))
        val avc = Format.Builder().setSampleMimeType(MimeTypes.VIDEO_H264).setDrmInitData(drm).build()
        val hevc = Format.Builder().setSampleMimeType(MimeTypes.VIDEO_H265).setDrmInitData(drm).build()
        val mixed = Tracks.Group(TrackGroup(avc, hevc), false,
            intArrayOf(C.FORMAT_UNSUPPORTED_DRM, C.FORMAT_UNSUPPORTED_SUBTYPE), booleanArrayOf(false, false))
        assertTrue(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(mixed))))
    }

    @Test fun potentiallyPlayableOverCapabilityTrackIsNotRejected() {
        assertFalse(VideoTrackSupport.hasDrmBlockedVideo(Tracks(listOf(
            group(MimeTypes.VIDEO_H264, true, C.FORMAT_UNSUPPORTED_DRM),
            group(MimeTypes.VIDEO_H264, false, C.FORMAT_EXCEEDS_CAPABILITIES),
        ))))
    }

    private fun group(mime: String, protected: Boolean, support: Int, selected: Boolean = false): Tracks.Group {
        val format = Format.Builder().setSampleMimeType(mime).apply {
            if (protected) setDrmInitData(DrmInitData("cbcs",
                DrmInitData.SchemeData(C.WIDEVINE_UUID, MimeTypes.VIDEO_MP4, byteArrayOf(1))))
        }.build()
        return Tracks.Group(TrackGroup(format), false, intArrayOf(support), booleanArrayOf(selected))
    }
}
