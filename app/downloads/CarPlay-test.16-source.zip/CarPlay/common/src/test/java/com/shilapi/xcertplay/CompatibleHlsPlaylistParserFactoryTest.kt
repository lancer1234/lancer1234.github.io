package com.shilapi.xcertplay

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.ParserException
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.hls.playlist.HlsMediaPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsMultivariantPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsPlaylistParser
import androidx.media3.exoplayer.hls.playlist.HlsRedundantGroup
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], manifest = Config.NONE)
@OptIn(UnstableApi::class)
class CompatibleHlsPlaylistParserFactoryTest {
    private val factory = CompatibleHlsPlaylistParserFactory()
    private val uri = Uri.parse("https://example.com/movie/master.m3u8")

    @Test fun reproducesStockFailureAndLoadsUnequalPathwaySetsWithoutDroppingQualities() {
        val text = playlist(complete = false)
        val original = stock(text)
        val failure = assertThrows(ParserException::class.java) {
            HlsRedundantGroup.Factory(original).createVariantRedundantGroupList()
        }
        assertTrue(failure.message!!.contains("inconsistent among variant redundant groups"))
        val result = factory.createPlaylistParser().parse(uri, text.byteInputStream()) as HlsMultivariantPlaylist
        assertNull(result.contentSteeringInfo)
        assertEquals(original.variants.map { it.url }, result.variants.map { it.url })
        assertEquals(original.variants.map { it.format }, result.variants.map { it.format })
        assertTrue(result.variants.all { it.pathwayId == null })
        assertEquals(2, HlsRedundantGroup.Factory(result).createVariantRedundantGroupList().size)
    }

    @Test fun leavesConsistentContentSteeringUnchanged() {
        val original = stock(playlist(complete = true))
        assertSame(original, factory.compatible(original))
        assertEquals("primary", original.contentSteeringInfo!!.pathwayId)
        assertEquals(2, HlsRedundantGroup.Factory(original).createVariantRedundantGroupList().size)
    }

    @Test fun leavesOrdinaryHlsUnchanged() {
        val original = stock(playlist(false).lineSequence()
            .filterNot { it.startsWith("#EXT-X-CONTENT-STEERING:") }.joinToString("\n"))
        assertSame(original, factory.compatible(original))
        val media = """
            #EXTM3U
            #EXT-X-TARGETDURATION:5
            #EXTINF:5,
            segment.ts
            #EXT-X-ENDLIST
        """.trimIndent()
        val result = factory.createPlaylistParser().parse(uri, media.byteInputStream()) as HlsMediaPlaylist
        assertEquals(1, result.segments.size)
        assertEquals(5_000_000L, result.durationUs)
    }

    @Test fun doesNotMaskConflictingUrlsOnTheSamePathway() {
        val text = playlist(false).replace("PATHWAY-ID=\"backup\"", "PATHWAY-ID=\"primary\"")
        val failure = assertThrows(ParserException::class.java) {
            factory.createPlaylistParser().parse(uri, text.byteInputStream())
        }
        assertTrue(failure.message!!.contains("Different playlist URLs"))
    }

    @Test fun alsoRecoversMissingAudioPathwaysAndKeepsRenditionLinks() {
        val text = """
            #EXTM3U
            #EXT-X-CONTENT-STEERING:SERVER-URI="steering.json",PATHWAY-ID="primary"
            #EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="Chinese",LANGUAGE="zh",DEFAULT=YES,AUTOSELECT=YES,URI="audio.m3u8",STABLE-RENDITION-ID="audio-zh"
            #EXT-X-STREAM-INF:BANDWIDTH=1000000,CODECS="avc1.42E01E,mp4a.40.2",AUDIO="audio",PATHWAY-ID="primary",STABLE-VARIANT-ID="hd"
            hd-primary.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=1000000,CODECS="avc1.42E01E,mp4a.40.2",PATHWAY-ID="backup",STABLE-VARIANT-ID="hd"
            hd-backup.m3u8
        """.trimIndent()
        val original = stock(text)
        assertThrows(ParserException::class.java) {
            HlsRedundantGroup.Factory(original).createRenditionRedundantGroupList(HlsRedundantGroup.AUDIO_RENDITION)
        }
        val result = factory.compatible(original)
        assertSame(original.audios[0], result.audios[0])
        assertEquals("audio", result.variants[0].audioGroupId)
        assertEquals(1, HlsRedundantGroup.Factory(result)
            .createRenditionRedundantGroupList(HlsRedundantGroup.AUDIO_RENDITION).size)
    }

    @Test fun preservesSessionDrmAndMediaEncryptionAndImportedVariables() {
        val text = playlist(false).replace("#EXTM3U", """
            #EXTM3U
            #EXT-X-DEFINE:NAME="keyRoot",VALUE="https://example.com/keys/"
            #EXT-X-INDEPENDENT-SEGMENTS
            #EXT-X-SESSION-KEY:METHOD=SAMPLE-AES,URI="https://example.com/license",KEYFORMAT="com.widevine"
        """.trimIndent())
        val original = stock(text)
        val result = factory.compatible(original)
        assertEquals(1, result.sessionKeyDrmInitData.size)
        assertSame(original.sessionKeyDrmInitData[0], result.sessionKeyDrmInitData[0])
        assertEquals(C.WIDEVINE_UUID, result.sessionKeyDrmInitData[0][0].uuid)
        assertEquals("cbcs", result.sessionKeyDrmInitData[0].schemeType)
        assertEquals(original.variableDefinitions, result.variableDefinitions)
        assertTrue(result.hasIndependentSegments)
        val media = """
            #EXTM3U
            #EXT-X-DEFINE:IMPORT="keyRoot"
            #EXT-X-TARGETDURATION:5
            #EXT-X-KEY:METHOD=AES-128,URI="{${'$'}keyRoot}video.key",IV=0x00000000000000000000000000000001
            #EXTINF:5,
            encrypted.ts
            #EXT-X-ENDLIST
        """.trimIndent()
        val parsed = factory.createPlaylistParser(result, null)
            .parse(uri, media.byteInputStream()) as HlsMediaPlaylist
        assertEquals("https://example.com/keys/video.key", parsed.segments.single().fullSegmentEncryptionKeyUri)
        assertEquals("0x00000000000000000000000000000001", parsed.segments.single().encryptionIV)
        assertEquals("encrypted.ts", parsed.segments.single().url)
    }

    @Test fun doesNotHideMalformedPlaylistSyntax() {
        val text = playlist(false).replace("#EXTM3U", "#EXTM3U\n#EXT-X-CONTENT-STEERING:SERVER-URI=\"other.json\"")
        assertThrows(ParserException::class.java) {
            factory.createPlaylistParser().parse(uri, text.byteInputStream())
        }
    }

    private fun stock(text: String) = HlsPlaylistParser().parse(uri, text.byteInputStream()) as HlsMultivariantPlaylist

    private fun playlist(complete: Boolean): String = """
        #EXTM3U
        #EXT-X-CONTENT-STEERING:SERVER-URI="steering.json",PATHWAY-ID="primary"
        #EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=1280x720,CODECS="avc1.42E01E",PATHWAY-ID="primary",STABLE-VARIANT-ID="hd"
        hd-primary.m3u8
        #EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=1280x720,CODECS="avc1.42E01E",PATHWAY-ID="backup",STABLE-VARIANT-ID="hd"
        hd-backup.m3u8
        #EXT-X-STREAM-INF:BANDWIDTH=500000,RESOLUTION=640x360,CODECS="avc1.42E01E",PATHWAY-ID="primary",STABLE-VARIANT-ID="sd"
        sd-primary.m3u8
    """.trimIndent() + if (complete) """

        #EXT-X-STREAM-INF:BANDWIDTH=500000,RESOLUTION=640x360,CODECS="avc1.42E01E",PATHWAY-ID="backup",STABLE-VARIANT-ID="sd"
        sd-backup.m3u8
    """.trimIndent().let { "\n$it" } else ""
}
