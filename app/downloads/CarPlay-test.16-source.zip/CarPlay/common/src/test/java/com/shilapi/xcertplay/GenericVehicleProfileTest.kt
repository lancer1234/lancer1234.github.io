package com.shilapi.xcertplay

import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.res.Resources
import com.shilapi.xcertplay.hud.BydNavigationOutputs
import com.shilapi.xcertplay.hud.BydOemClusterHold
import com.shilapi.xcertplay.hud.BydOutputSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33], manifest = Config.NONE)
class GenericVehicleProfileTest {
    private val app get() = RuntimeEnvironment.getApplication()

    @Suppress("DEPRECATION")
    private fun genericContext(): Context {
        val resources = object : Resources(app.resources.assets, app.resources.displayMetrics, app.resources.configuration) {
            override fun getBoolean(id: Int): Boolean =
                if (id == com.shilapi.xcertplay.shared.R.bool.config_byd_integration) false else super.getBoolean(id)
        }
        return object : ContextWrapper(app) {
            override fun getResources(): Resources = resources
            override fun getApplicationContext(): Context = this
        }
    }

    @Test fun genericProfileIgnoresVendorSelectionsEvenOnVendorHardware() {
        shadowOf(app.packageManager).installPackage(PackageInfo().apply {
            packageName = "com.byd.carsettings"
            applicationInfo = ApplicationInfo().apply { flags = ApplicationInfo.FLAG_SYSTEM }
        })
        val context = genericContext()
        BydOutputSettings.setEnabled(context, true)
        BydOutputSettings.setBatteryToIphone(context, true)
        BydOutputSettings.setWheelSpeedToIphone(context, true)
        BydOutputSettings.setVideoWhileParked(context, true)
        BydOutputSettings.setClusterSong(context, true)
        BydOutputSettings.setHudSong(context, true)
        BydOutputSettings.setOemClusterHold(context, BydOemClusterHold.PACKAGE)
        assertFalse(BydOutputSettings.available(context))
        assertFalse(BydOutputSettings.enabled(context))
        assertFalse(BydOutputSettings.batteryToIphoneActive(context))
        assertFalse(BydOutputSettings.wheelSpeedToIphoneActive(context))
        assertFalse(BydOutputSettings.videoWhileParkedActive(context))
        assertFalse(BydOutputSettings.clusterSong(context))
        assertFalse(BydOutputSettings.hudSong(context))
        assertEquals(BydOemClusterHold.OFF, BydOutputSettings.oemClusterHold(context))
        assertFalse(CarHotspotSetup.isBydHeadUnit(context))
        assertNull(BydNavigationOutputs.parked(context))
        BydNavigationOutputs.start(context)
        for (name in listOf("standalone", "hud", "cluster")) {
            val worker = BydNavigationOutputs::class.java.getDeclaredField(name).apply { isAccessible = true }.get(BydNavigationOutputs)
            assertFalse(worker.javaClass.getDeclaredField("accepting").apply { isAccessible = true }.getBoolean(worker))
        }
    }

    @Test fun defaultNavigationRequiresAReceiverAndKeepsExplicitOptOut() {
        app.getSharedPreferences("diplay_byd_outputs", 0).edit().clear().commit()
        assertFalse(BydOutputSettings.enabled(app))
        shadowOf(app.packageManager).installPackage(PackageInfo().apply {
            packageName = "com.ts.car.someip.service"
            applicationInfo = ApplicationInfo().apply { packageName = "com.ts.car.someip.service" }
        })
        assertTrue(BydOutputSettings.enabled(app))
        BydOutputSettings.setEnabled(app, false)
        assertFalse(BydOutputSettings.enabled(app))
    }
}
