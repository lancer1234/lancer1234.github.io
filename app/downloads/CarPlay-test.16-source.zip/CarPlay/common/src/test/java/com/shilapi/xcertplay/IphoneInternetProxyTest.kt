package com.shilapi.xcertplay

import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import org.bouncycastle.tls.AbstractTlsServer
import org.bouncycastle.tls.BasicTlsPSKExternal
import org.bouncycastle.tls.ProtocolVersion
import org.bouncycastle.tls.TlsPSKExternal
import org.bouncycastle.tls.PskIdentity
import org.bouncycastle.tls.CipherSuite
import org.bouncycastle.tls.PSKTlsServer
import org.bouncycastle.tls.TlsPSKIdentityManager
import org.bouncycastle.tls.TlsServerProtocol
import org.bouncycastle.tls.crypto.impl.bc.BcTlsCrypto
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.net.ServerSocket
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE)
@OptIn(UnstableApi::class)
class IphoneInternetProxyTest {
    private val key = ByteArray(32) { (it + 1).toByte() }
    private val identity = "test-session-identity".toByteArray()
    private fun params(port: Int = 12345) = mutableMapOf<String, Any?>(
        "proxyUrl" to "https://127.0.0.1", "proxyPort" to port,
        "proxyAuthorization" to "Basic synthetic-test-credential", "proxyPsk" to key, "proxyPskIdentity" to identity,
    )

    @Test fun credentialsCannotSelectAnotherHostOrInjectHeaders() {
        for (url in listOf("https://192.0.2.1", "file:///private", "https://user:pass@127.0.0.1")) {
            assertNull(IphoneProxyParameters.parse("127.0.0.1", null, params().apply { put("proxyUrl", url) }))
        }
        assertNull(IphoneProxyParameters.parse("127.0.0.1", null, params().apply { put("proxyAuthorization", "Basic x\r\nInjected: yes") }))
        assertNull(IphoneProxyParameters.parse("127.0.0.1", null, params(65536)))
        assertNull(IphoneProxyParameters.parse("127.0.0.1", null, params().apply { remove("proxyPsk") }))
    }

    @Test fun sessionCopiesKeysAndDoesNotExposeThemInDiagnostics() {
        val config = IphoneProxyParameters.parse("127.0.0.1", null, params())!!
        assertNotSame(key, config.key)
        assertNotSame(identity, config.identity)
        config.key.fill(0)
        assertEquals(1.toByte(), key[0])
        assertFalse(config.toString().contains("synthetic-test-credential"))
    }

    @Test fun encryptedProxyCarriesRangeAndAuthWithoutResolvingOriginLocally() = verifyTransfer(false)
    @Test fun tls13OnlyProxyCarriesRangeAndAuth() = verifyTransfer(true)

    @Test fun tls13ProxyWithPurePskAndRequiredHttpAlpnWorks() = verifyTransfer(true, purePsk = true)
    @Test fun retriesSha384ExternalPskAfterRejectedBinderProfile() = verifyTransfer(true, sha384 = true)

    private fun verifyTransfer(tls13: Boolean, purePsk: Boolean = false, sha384: Boolean = false) {
        ServerSocket(0).use { phone ->
            val received = CompletableFuture<String>()
            val done = CompletableFuture<Unit>()
            Thread {
                try {
                    if (sha384) phone.accept().use { first ->
                        first.soTimeout = 5000
                        val input = java.io.DataInputStream(first.getInputStream())
                        input.readUnsignedByte(); input.readUnsignedShort()
                        val hello = ByteArray(input.readUnsignedShort()); input.readFully(hello)
                        first.getOutputStream().write(byteArrayOf(21, 3, 3, 0, 2, 2, 51))
                    }
                    phone.accept().use { socket ->
                        socket.soTimeout = 5000
                        val tls = TlsServerProtocol(socket.getInputStream(), socket.getOutputStream())
                        val server = if (tls13) object : AbstractTlsServer(BcTlsCrypto()) {
                            override fun getCredentials(): org.bouncycastle.tls.TlsCredentials? = null
                            override fun getSupportedVersions() = arrayOf(ProtocolVersion.TLSv13)
                            override fun getSupportedCipherSuites() = intArrayOf(if (sha384) CipherSuite.TLS_AES_256_GCM_SHA384 else CipherSuite.TLS_AES_128_GCM_SHA256)
                            override fun getProtocolNames() = java.util.Vector<org.bouncycastle.tls.ProtocolName>().apply { add(org.bouncycastle.tls.ProtocolName.HTTP_1_1) }
                            override fun getPskKeyExchangeModes() = if (purePsk) shortArrayOf(org.bouncycastle.tls.PskKeyExchangeMode.psk_ke) else super.getPskKeyExchangeModes()
                            override fun getExternalPSK(identities: java.util.Vector<*>): TlsPSKExternal? {
                                return if (identities.any { (it as PskIdentity).identity.contentEquals(identity) })
                                    BasicTlsPSKExternal(identity, crypto.createSecret(key), if (sha384) org.bouncycastle.tls.PRFAlgorithm.tls13_hkdf_sha384 else org.bouncycastle.tls.PRFAlgorithm.tls13_hkdf_sha256) else null
                            }
                        } else object : PSKTlsServer(BcTlsCrypto(), object : TlsPSKIdentityManager {
                            override fun getHint(): ByteArray? = null
                            override fun getPSK(candidate: ByteArray): ByteArray? = if (candidate.contentEquals(identity)) key.copyOf() else null
                        }) {
                            override fun getSupportedCipherSuites() = intArrayOf(CipherSuite.TLS_PSK_WITH_AES_128_GCM_SHA256)
                        }
                        tls.accept(server)
                        received.complete(IphoneInternetProxy.readHeader(tls.inputStream))
                        tls.outputStream.write("HTTP/1.1 206 Partial Content\r\nContent-Length: 2\r\nContent-Range: bytes 1-2/4\r\nConnection: close\r\n\r\nbc".toByteArray())
                        tls.outputStream.flush()
                        Thread.sleep(100)
                    }
                    done.complete(Unit)
                } catch (e: Throwable) { received.completeExceptionally(e); done.completeExceptionally(e) }
            }.apply { isDaemon = true; start() }
            IphoneInternetProxy(IphoneProxyParameters.parse("127.0.0.1", null, params(phone.localPort))!!).use { proxy ->
                val source = proxy.factory.createDataSource()
                try {
                    assertEquals(2L, source.open(DataSpec.Builder().setUri("http://no-local-dns.invalid/video").setPosition(1).setLength(2).build()))
                    val bytes = ByteArray(2)
                    assertEquals(2, source.read(bytes, 0, 2))
                    assertArrayEquals("bc".toByteArray(), bytes)
                    val request = received.get(5, TimeUnit.SECONDS)
                    assertTrue(request.startsWith("GET http://no-local-dns.invalid/video HTTP/1.1"))
                    assertTrue(request.contains("Range: bytes=1-2"))
                    assertTrue(request.contains("Proxy-Authorization: Basic synthetic-test-credential"))
                    assertFalse(request.split("\r\n").any { it.startsWith("Authorization:", true) })
                } finally { source.close() }
            }
            done.get(5, TimeUnit.SECONDS)
        }
    }

    @Test fun incorrectSessionKeyFailsBeforeSendingProxyAuthorization() {
        ServerSocket(0).use { phone ->
            val delivered = CompletableFuture<Boolean>()
            Thread {
                try {
                    phone.accept().use { socket ->
                        socket.soTimeout = 5000
                        val tls = TlsServerProtocol(socket.getInputStream(), socket.getOutputStream())
                        try {
                            tls.accept(object : PSKTlsServer(BcTlsCrypto(), object : TlsPSKIdentityManager {
                                override fun getHint(): ByteArray? = null
                                override fun getPSK(candidate: ByteArray): ByteArray = ByteArray(32) { 99 }
                            }) {
                                override fun getSupportedCipherSuites() = intArrayOf(CipherSuite.TLS_PSK_WITH_AES_128_GCM_SHA256)
                            })
                            delivered.complete(true)
                        } catch (_: java.io.IOException) { delivered.complete(false) }
                    }
                } catch (e: Throwable) { delivered.completeExceptionally(e) }
            }.apply { isDaemon = true; start() }
            IphoneInternetProxy(IphoneProxyParameters.parse("127.0.0.1", null, params(phone.localPort))!!).use { proxy ->
                val source = proxy.factory.createDataSource()
                try {
                    assertThrows(java.io.IOException::class.java) {
                        source.open(DataSpec.Builder().setUri("http://no-local-dns.invalid/video").build())
                    }
                    assertFalse(delivered.get(5, TimeUnit.SECONDS))
                } finally { source.close() }
            }
        }
    }

    @Test fun headersHaveBoundedSizeAndRequireCompleteTermination() {
        assertThrows(java.io.IOException::class.java) { IphoneInternetProxy.readHeader(ByteArrayInputStream("HTTP/1.1 200 OK\r\n".toByteArray())) }
        assertThrows(java.io.IOException::class.java) { IphoneInternetProxy.readHeader(ByteArrayInputStream(ByteArray(65537) { 65 })) }
    }
}
