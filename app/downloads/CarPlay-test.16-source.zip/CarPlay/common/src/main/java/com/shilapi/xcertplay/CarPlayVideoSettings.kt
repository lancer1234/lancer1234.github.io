package com.shilapi.xcertplay

import android.content.Context
import com.shilapi.xcertplay.hud.BydOutputSettings

/** Explicit stationary testing mode for receivers without vehicle gear data. */
internal object CarPlayVideoSettings {
    private const val PREFS = "diplay_video"
    private const val KEY_STANDALONE = "stationary_test_enabled"

    fun standaloneEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_STANDALONE, false)

    fun setStandaloneEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_STANDALONE, enabled).apply()
    }

    /** Movie-only loudness compensation, in millibels; system/music volume is independent. */
    fun volumeBoost(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("volume_boost_mb", 600)
            .takeIf { it in listOf(0, 600, 1200) } ?: 600

    fun setVolumeBoost(context: Context, gain: Int) {
        require(gain in listOf(0, 600, 1200))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("volume_boost_mb", gain).apply()
    }

    fun offered(context: Context): Boolean =
        standaloneEnabled(context) || BydOutputSettings.videoWhileParkedActive(context)

    fun parked(context: Context, vehicleParked: Boolean?): Boolean? =
        vehicleParked ?: if (standaloneEnabled(context)) true else null
}
