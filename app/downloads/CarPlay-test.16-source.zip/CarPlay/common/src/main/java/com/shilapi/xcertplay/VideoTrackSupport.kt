package com.shilapi.xcertplay

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi

/** A ready text/audio track alone must not make an unsupported protected movie appear playable. */
@OptIn(UnstableApi::class)
internal object VideoTrackSupport {
    fun hasDrmBlockedVideo(tracks: Tracks): Boolean {
        val video = tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
        val noUsableVideo = video.isNotEmpty() && video.all { group ->
            !group.isSelected && group.length > 0 && (0 until group.length).all { index ->
                group.getTrackSupport(index) in setOf(C.FORMAT_UNSUPPORTED_TYPE,
                    C.FORMAT_UNSUPPORTED_SUBTYPE, C.FORMAT_UNSUPPORTED_DRM)
            }
        }
        // A multivariant movie may also include unsupported HEVC/Dolby Vision renditions.
        // Those must not mask the DRM rejection on otherwise decodable AVC renditions.
        return noUsableVideo && video.any { group ->
            (0 until group.length).any { index ->
                group.getTrackFormat(index).drmInitData != null &&
                    group.getTrackSupport(index) == C.FORMAT_UNSUPPORTED_DRM
            }
        }
    }
}
