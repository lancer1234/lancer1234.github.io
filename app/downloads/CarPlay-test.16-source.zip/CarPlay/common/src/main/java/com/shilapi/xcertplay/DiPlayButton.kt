// SPDX-License-Identifier: AGPL-3.0-only
package com.shilapi.xcertplay

import android.animation.ValueAnimator
import android.content.Context
import android.view.MotionEvent
import android.view.animation.PathInterpolator
import android.widget.Button

/** Native click/cancel semantics, with brief feedback only for touch input. */
internal class DiPlayButton(context: Context) : Button(context) {
    private var handlingTouch = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        handlingTouch = true
        try {
            return super.onTouchEvent(event)
        } finally {
            handlingTouch = false
        }
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (!changed) return
        animate().cancel()
        // Keyboard/remote actions stay immediate; honour Android's animation-off setting.
        if (handlingTouch && isEnabled && ValueAnimator.areAnimatorsEnabled()) {
            val scale = if (pressed) 0.97f else 1f
            animate().scaleX(scale).scaleY(scale).setDuration(120)
                .setInterpolator(PathInterpolator(0.23f, 1f, 0.32f, 1f)).start()
        } else {
            scaleX = 1f
            scaleY = 1f
        }
    }

    override fun onDetachedFromWindow() {
        animate().cancel()
        scaleX = 1f
        scaleY = 1f
        super.onDetachedFromWindow()
    }
}
