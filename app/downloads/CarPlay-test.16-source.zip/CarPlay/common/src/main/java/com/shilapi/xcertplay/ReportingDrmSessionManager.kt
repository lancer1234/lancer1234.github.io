package com.shilapi.xcertplay

import androidx.annotation.OptIn
import androidx.media3.common.Format
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.drm.DrmSession
import androidx.media3.exoplayer.drm.DrmSessionEventListener
import androidx.media3.exoplayer.drm.DrmSessionManager

/** Report synchronous session failures, which DRM_UNSUPPORTED doesn't send as analytics events.
 * Only actual sample-reader acquisition is reported; playlist discovery and preacquisition aren't
 * playback failures. The delegate remains responsible for encryption and all session lifetimes. */
@OptIn(UnstableApi::class)
internal class ReportingDrmSessionManager(
    private val delegate: DrmSessionManager,
    private val onError: (Format, DrmSession.DrmSessionException) -> Unit,
) : DrmSessionManager by delegate {
    override fun acquireSession(eventDispatcher: DrmSessionEventListener.EventDispatcher?, format: Format): DrmSession? {
        val session = delegate.acquireSession(eventDispatcher, format)
        if (session?.state == DrmSession.STATE_ERROR) {
            session.error?.let { onError(format, it) }
        }
        return session
    }
}
