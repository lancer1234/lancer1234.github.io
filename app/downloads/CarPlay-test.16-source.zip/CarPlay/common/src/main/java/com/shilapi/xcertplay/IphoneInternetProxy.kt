package com.shilapi.xcertplay

import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.okhttp.OkHttpDataSource
import okhttp3.OkHttpClient
import org.bouncycastle.tls.BasicTlsPSKExternal
import org.bouncycastle.tls.ProtocolName
import org.bouncycastle.tls.PskKeyExchangeMode
import org.bouncycastle.tls.PRFAlgorithm
import org.bouncycastle.tls.ProtocolVersion
import org.bouncycastle.tls.TlsFatalAlertReceived
import org.bouncycastle.tls.TlsFatalAlert
import org.bouncycastle.tls.CipherSuite
import org.bouncycastle.tls.PSKTlsClient
import org.bouncycastle.tls.TlsClientProtocol
import org.bouncycastle.tls.crypto.impl.bc.BcTlsCrypto
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Credentials stay in memory and belong to one authenticated CarPlay session. */
internal class IphoneProxyParameters private constructor(
    val peer: InetAddress,
    val port: Int,
    val localAddress: InetAddress?,
    val authorization: String,
    val identity: ByteArray,
    val key: ByteArray,
) {
    companion object {
        fun parse(peerHost: String, localAddress: InetAddress?, params: Map<String, Any?>): IphoneProxyParameters? {
            val uri = runCatching { URI(params["proxyUrl"] as? String ?: return null) }.getOrNull() ?: return null
            if (uri.scheme !in setOf("http", "https") || uri.host == null || uri.userInfo != null) return null
            // Never send session credentials to a host supplied by a media URL or redirect.
            val peer = runCatching { InetAddress.getByName(peerHost) }.getOrNull() ?: return null
            val advertised = runCatching { InetAddress.getByName(uri.host) }.getOrNull() ?: return null
            if (advertised != peer) return null
            val port = (params["proxyPort"] as? Number)?.toInt() ?: uri.port
            if (port !in 1..65535) return null
            val auth = params["proxyAuthorization"] as? String ?: return null
            if (auth.length > 4096 || auth.any { it.code !in 32..126 }) return null
            fun bytes(value: Any?): ByteArray? = when (value) {
                is ByteArray -> value.copyOf()
                is String -> value.toByteArray(StandardCharsets.UTF_8)
                else -> null
            }
            val identity = bytes(params["proxyPskIdentity"]) ?: return null
            val key = bytes(params["proxyPsk"]) ?: return null
            if (identity.isEmpty() || identity.size > 4096 || key.isEmpty() || key.size > 4096) return null
            return IphoneProxyParameters(peer, port, localAddress, auth, identity, key)
        }
    }
}

/**
 * Adapts the session's TLS-PSK HTTP proxy to Media3's ordinary HTTP proxy support. Only the
 * movie client uses this loopback listener: Android's system proxy and CarPlay audio are untouched.
 * Origin HTTPS remains end-to-end, including certificate and hostname verification in OkHttp.
 */
@OptIn(UnstableApi::class)
internal class IphoneInternetProxy(private val parameters: IphoneProxyParameters) : Closeable {
    @Volatile private var preferredSha384 = false
    private val stopped = AtomicBoolean(false)
    private val sockets = ConcurrentHashMap.newKeySet<Socket>()
    private val slots = java.util.concurrent.Semaphore(5)
    private val workers = Executors.newFixedThreadPool(12) { Thread(it, "carplay-video-proxy").apply { isDaemon = true } }
    private val server = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
    private val localAuthorization = "CarPlayLocal " + java.util.UUID.randomUUID()
    private val client = OkHttpClient.Builder()
        .proxy(Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", server.localPort)))
        .proxyAuthenticator { _, response ->
            if (response.request.header("Proxy-Authorization") == localAuthorization) null
            else response.request.newBuilder().header("Proxy-Authorization", localAuthorization).build()
        }
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
        .connectionPool(okhttp3.ConnectionPool(0, 1, TimeUnit.SECONDS))
        .build()
    val factory: DataSource.Factory = OkHttpDataSource.Factory(client)

    init {
        Thread({
            while (!stopped.get()) {
                try {
                    val incoming = server.accept()
                    if (!slots.tryAcquire()) { incoming.close(); continue }
                    sockets.add(incoming)
                    if (stopped.get()) { incoming.close(); sockets.remove(incoming); slots.release() }
                    else workers.execute { bridge(incoming) }
                } catch (_: IOException) { if (!stopped.get()) Log.w(TAG, "proxy accept failed") }
            }
        }, "carplay-video-proxy-accept").apply { isDaemon = true; start() }
    }

    private fun bridge(incoming: Socket) {
        var remote = Socket()
        sockets.add(remote)
        val clientEnded = AtomicBoolean(false)
        var downloadedBytes = 0L
        try {
            incoming.soTimeout = 20_000
            val header = readHeader(incoming.getInputStream())
            val supplied = header.split("\r\n").firstOrNull { it.startsWith("Proxy-Authorization:", true) }
                ?.substringAfter(':')?.trim()
            if (supplied != localAuthorization) {
                incoming.getOutputStream().write("HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: CarPlayLocal\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray(StandardCharsets.ISO_8859_1))
                return
            }
            val first = header.substringBefore("\r\n")
            if (!first.startsWith("CONNECT ") && !first.startsWith("GET http://") && !first.startsWith("HEAD http://")) {
                throw IOException("Unsupported proxy method")
            }
            val firstSha384 = preferredSha384
            val tls = try {
                connectTls(remote, sha384 = firstSha384)
            } catch (error: TlsFatalAlertReceived) {
                if (error.alertDescription.toInt() !in setOf(40, 51) || stopped.get()) throw error
                // Raw TLS 1.3 external PSKs carry no hash preference in setProxyParameters.
                // Try the other standard binder hash before giving up; never downgrade to plaintext.
                remote.close(); sockets.remove(remote)
                remote = Socket(); sockets.add(remote)
                Log.i(TAG, "iPhone proxy retry with alternate external PSK hash")
                connectTls(remote, sha384 = !firstSha384).also { preferredSha384 = !firstSha384 }
            }
            Log.i(TAG, "iPhone proxy TLS authenticated")
            val lines = header.removeSuffix("\r\n\r\n").split("\r\n")
                .filterNot { it.startsWith("Proxy-Authorization:", true) || it.startsWith("Proxy-Connection:", true) }
            val request = (lines + "Proxy-Authorization: ${parameters.authorization}" + "Proxy-Connection: close")
                .joinToString("\r\n", postfix = "\r\n\r\n")
            tls.outputStream.write(request.toByteArray(StandardCharsets.ISO_8859_1))
            tls.outputStream.flush()
            val response = readHeader(tls.inputStream)
            val status = response.substringBefore("\r\n").split(' ').getOrNull(1)?.toIntOrNull()
            Log.i(TAG, "iPhone proxy response status=$status tunnel=${first.startsWith("CONNECT ")}")
            incoming.getOutputStream().write(response.toByteArray(StandardCharsets.ISO_8859_1))
            incoming.getOutputStream().flush()
            if (first.startsWith("CONNECT ") && status != 200) return
            workers.execute {
                try { incoming.getInputStream().copyTo(tls.outputStream, 32 * 1024); clientEnded.set(true) }
                catch (_: IOException) { /* Closing either side interrupts the other direction. */ }
                finally { runCatching { remote.close() } }
            }
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val count = tls.inputStream.read(buffer)
                if (count < 0) break
                incoming.getOutputStream().write(buffer, 0, count)
                downloadedBytes += count
            }
        } catch (error: Exception) {
            // Neither exception messages nor URLs are logged: both may contain credentials.
            val alert = when (error) {
                is TlsFatalAlertReceived -> error.alertDescription
                is TlsFatalAlert -> error.alertDescription
                else -> null
            }
            if (clientEnded.get()) Log.d(TAG, "iPhone proxy tunnel closed downloadBytes=$downloadedBytes")
            else Log.w(TAG, "iPhone proxy transport failed: ${error.javaClass.simpleName} alert=$alert")
        } finally {
            runCatching { remote.close() }
            runCatching { incoming.close() }
            sockets.remove(remote); sockets.remove(incoming)
            slots.release()
        }
    }

    private fun connectTls(remote: Socket, sha384: Boolean): TlsClientProtocol {
        parameters.localAddress?.let { remote.bind(InetSocketAddress(it, 0)) }
        remote.connect(InetSocketAddress(parameters.peer, parameters.port), 10_000)
        remote.soTimeout = 20_000
        remote.tcpNoDelay = true
        val tls = TlsClientProtocol(remote.getInputStream(), remote.getOutputStream())
        tls.connect(object : PSKTlsClient(BcTlsCrypto(), parameters.identity, parameters.key) {
            override fun getSupportedVersions() = arrayOf(ProtocolVersion.TLSv13, ProtocolVersion.TLSv12)
            override fun getProtocolNames() = java.util.Vector<ProtocolName>().apply { add(ProtocolName.HTTP_1_1) }
            override fun getPskKeyExchangeModes() = shortArrayOf(PskKeyExchangeMode.psk_dhe_ke, PskKeyExchangeMode.psk_ke)
            override fun notifyServerVersion(version: ProtocolVersion) {
                super.notifyServerVersion(version)
                Log.i(TAG, "iPhone proxy server version=$version")
            }
            override fun notifySelectedCipherSuite(cipherSuite: Int) {
                super.notifySelectedCipherSuite(cipherSuite)
                Log.i(TAG, "iPhone proxy selected cipher=$cipherSuite")
            }
            override fun getExternalPSKs(): java.util.Vector<BasicTlsPSKExternal> = java.util.Vector<BasicTlsPSKExternal>().apply {
                add(BasicTlsPSKExternal(parameters.identity, crypto.createSecret(parameters.key), if (sha384) PRFAlgorithm.tls13_hkdf_sha384 else PRFAlgorithm.tls13_hkdf_sha256))
            }
            override fun notifyAlertReceived(level: Short, description: Short) {
                Log.w(TAG, "iPhone proxy TLS alert level=$level description=$description")
                super.notifyAlertReceived(level, description)
            }
            override fun notifyHandshakeComplete() {
                super.notifyHandshakeComplete()
                Log.i(TAG, "iPhone proxy TLS version=${context.securityParametersConnection.negotiatedVersion}")
            }
            override fun getSupportedCipherSuites(): IntArray = intArrayOf(
                CipherSuite.TLS_AES_256_GCM_SHA384,
                CipherSuite.TLS_AES_128_GCM_SHA256,
                CipherSuite.TLS_CHACHA20_POLY1305_SHA256,
                CipherSuite.TLS_PSK_WITH_AES_128_GCM_SHA256,
                CipherSuite.TLS_PSK_WITH_AES_256_GCM_SHA384,
                CipherSuite.TLS_PSK_WITH_AES_128_CBC_SHA256,
                CipherSuite.TLS_PSK_WITH_AES_256_CBC_SHA384,
                CipherSuite.TLS_PSK_WITH_AES_128_CBC_SHA,
                CipherSuite.TLS_PSK_WITH_AES_256_CBC_SHA,
                CipherSuite.TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA,
                CipherSuite.TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256,
            )
            })
        return tls
    }

    override fun close() {
        if (!stopped.compareAndSet(false, true)) return
        server.close()
        client.dispatcher.cancelAll()
        client.connectionPool.evictAll()
        sockets.forEach { runCatching { it.close() } }
        sockets.clear()
        workers.shutdownNow()
        // Workers may still unwind; they own no persistent copy of credentials.
        parameters.key.fill(0)
        parameters.identity.fill(0)
    }

    companion object {
        private const val TAG = "CarPlay-Video"
        internal fun readHeader(input: InputStream): String {
            val result = java.io.ByteArrayOutputStream()
            var tail = 0
            while (result.size() < 64 * 1024) {
                val value = input.read()
                if (value == -1) throw IOException("Incomplete proxy header")
                result.write(value)
                tail = (tail shl 8) or value
                if (tail == 0x0d0a0d0a) return result.toString("ISO-8859-1")
            }
            throw IOException("Oversized proxy header")
        }
    }
}

/** Pick the current session at open(), so a newly created player never retains an old proxy. */
@OptIn(UnstableApi::class)
internal class SessionVideoDataSource(private val direct: DataSource.Factory, private val proxy: () -> DataSource.Factory?) : DataSource {
    private var current: DataSource? = null
    private val listeners = mutableListOf<TransferListener>()
    override fun addTransferListener(listener: TransferListener) { listeners.add(listener); current?.addTransferListener(listener) }
    override fun open(dataSpec: DataSpec): Long {
        check(current == null)
        val http = dataSpec.uri.scheme in setOf("http", "https")
        val selected = (if (http) proxy() else null) ?: direct
        val next = selected.createDataSource()
        current = next
        listeners.forEach(next::addTransferListener)
        return try { next.open(dataSpec) } catch (error: Exception) { close(); throw error }
    }
    override fun read(buffer: ByteArray, offset: Int, length: Int) = current?.read(buffer, offset, length) ?: throw IOException("not open")
    override fun getUri() = current?.uri
    override fun getResponseHeaders() = current?.responseHeaders ?: emptyMap()
    override fun close() { try { current?.close() } finally { current = null } }
}
