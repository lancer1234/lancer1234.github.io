package com.shilapi.xcertplay

import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.ParserException
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.hls.playlist.DefaultHlsPlaylistParserFactory
import androidx.media3.exoplayer.hls.playlist.HlsMediaPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsMultivariantPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsPlaylistParserFactory
import androidx.media3.exoplayer.hls.playlist.HlsRedundantGroup
import androidx.media3.exoplayer.upstream.ParsingLoadable

/**
 * Some AirPlay playlists advertise different CDN pathway sets for different qualities. Media3
 * rejects these before it opens a media playlist. If (and only if) its steering validation rejects
 * those sets, use the ordinary HLS redundancy mechanism with the URLs already in the playlist.
 * Segment URLs, audio/subtitle links, variable definitions and all encryption data stay intact.
 */
@OptIn(UnstableApi::class)
internal class CompatibleHlsPlaylistParserFactory : HlsPlaylistParserFactory {
    private val delegate = DefaultHlsPlaylistParserFactory()

    override fun createPlaylistParser(): ParsingLoadable.Parser<HlsPlaylist> =
        wrap(delegate.createPlaylistParser())

    override fun createPlaylistParser(
        multivariantPlaylist: HlsMultivariantPlaylist,
        previousMediaPlaylist: HlsMediaPlaylist?,
    ): ParsingLoadable.Parser<HlsPlaylist> =
        wrap(delegate.createPlaylistParser(multivariantPlaylist, previousMediaPlaylist))

    private fun wrap(parser: ParsingLoadable.Parser<HlsPlaylist>) =
        ParsingLoadable.Parser<HlsPlaylist> { uri, input ->
            val playlist = parser.parse(uri, input)
            if (playlist is HlsMultivariantPlaylist) compatible(playlist) else playlist
        }

    internal fun compatible(playlist: HlsMultivariantPlaylist): HlsMultivariantPlaylist {
        if (playlist.contentSteeringInfo == null) return playlist
        try {
            validate(playlist)
            return playlist
        } catch (error: ParserException) {
            // Do not mask unrelated malformed manifests or conflicting URLs for the same pathway.
            if (error.message?.substringBefore(" {contentIsMalformed=") !in PATHWAY_SET_ERRORS) throw error
        }
        val fallback = HlsMultivariantPlaylist(
            playlist.baseUri,
            playlist.tags,
            playlist.variants.map { variant ->
                HlsMultivariantPlaylist.Variant(
                    variant.url, variant.format, variant.videoGroupId, variant.audioGroupId,
                    variant.subtitleGroupId, variant.captionGroupId, null, variant.stableVariantId,
                )
            },
            playlist.videos, playlist.audios, playlist.subtitles, playlist.closedCaptions,
            playlist.muxedAudioFormat, playlist.muxedCaptionFormats, playlist.hasIndependentSegments,
            playlist.variableDefinitions, playlist.sessionKeyDrmInitData, null,
        )
        validate(fallback)
        // No URLs or playlist text: they can contain access tokens and content key metadata.
        Log.i("CarPlay-Video", "HLS steering fallback: inconsistent pathway sets; variants=${fallback.variants.size}")
        return fallback
    }

    private fun validate(playlist: HlsMultivariantPlaylist) {
        val groups = HlsRedundantGroup.Factory(playlist)
        groups.createVariantRedundantGroupList()
        for (type in listOf(HlsRedundantGroup.VIDEO_RENDITION,
            HlsRedundantGroup.AUDIO_RENDITION, HlsRedundantGroup.SUBTITLE_RENDITION)) {
            groups.createRenditionRedundantGroupList(type)
        }
    }

    private companion object {
        val PATHWAY_SET_ERRORS = setOf(
            "The set of available pathway IDs is inconsistent among variant redundant groups",
            "The set of available pathway IDs of a rendition redundant group is inconsistent with variant redundant groups",
        )
    }
}
