package com.shilapi.xcertplay.network

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

internal fun wirelessHostAddress(addresses: List<InetAddress>, interfaceIndex: Int): InetAddress? {
    val selected = HotspotAddressPolicy.select(addresses) ?: return null
    if (selected is Inet6Address && interfaceIndex > 0) {
        return Inet6Address.getByAddress(null, selected.address, interfaceIndex)
    }
    return selected
}

/** Station LAN discovery must cover IPv4 multicast as well as scoped link-local IPv6. */
internal fun existingWifiHostAddresses(addresses: List<InetAddress>, interfaceIndex: Int): List<InetAddress> {
    val ipv4 = addresses.firstOrNull {
        it is Inet4Address && !it.isLoopbackAddress && !it.isLinkLocalAddress &&
            !it.isAnyLocalAddress && !it.isMulticastAddress
    }
    val ipv6 = if (interfaceIndex > 0) {
        addresses.filterIsInstance<Inet6Address>().firstOrNull { it.isLinkLocalAddress }?.let {
            Inet6Address.getByAddress(null, it.address, interfaceIndex)
        }
    } else {
        null
    }
    return listOfNotNull(ipv4, ipv6)
}

/** Serve both AP families; prefer IPv4 when the phone chooses its bootstrap endpoint. */
internal fun manualHotspotHostAddresses(primary: InetAddress, addresses: List<InetAddress>): List<InetAddress> =
    (addresses.filter { it is Inet4Address && it.isSiteLocalAddress } + primary).distinct()

/** Legacy Android APs can expose link-local IPv6 that clients cannot reach. */
internal fun manualHotspotBootstrapAddresses(addresses: List<InetAddress>): List<InetAddress> =
    addresses.filterIsInstance<Inet4Address>().ifEmpty { addresses }
