package com.shilapi.xcertplay.media

/** Optional input boost with a per-frame peak limit. Never keeps microphone samples. */
internal object MicrophonePcmGain {
    fun apply(pcm: ByteArray, level: Int) {
        val multiplier = when (level.coerceIn(0, 2)) { 1 -> 2.0; 2 -> 4.0; else -> return }
        var peak = 0
        for (i in 0 until (pcm.size - 1) step 2) peak = maxOf(peak, kotlin.math.abs(sample(pcm, i)))
        if (peak == 0) return
        val gain = minOf(multiplier, 32000.0 / peak)
        for (i in 0 until (pcm.size - 1) step 2) {
            val value = (sample(pcm, i) * gain).toInt().coerceIn(-32000, 32000)
            pcm[i] = value.toByte()
            pcm[i + 1] = (value shr 8).toByte()
        }
    }
    private fun sample(pcm: ByteArray, i: Int): Int =
        ((pcm[i].toInt() and 255) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
}
