package com.shilapi.xcertplay

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.roundToInt

/** Movie-only PCM gain, independent of vendor AudioEffect implementations and system volume. */
@UnstableApi
internal class MovieVolumeProcessor : BaseAudioProcessor() {
    // Keep the saved 0/600/1200 choices compatible with previous APKs.
    // Strong now supplies 24 dB (about 16x) instead of the old 12 dB system effect.
    @Volatile var boostMb: Int = 600

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        // Stay active even at unity: a live choice change must not need to rebuild the audio sink.
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val output = replaceOutputBuffer(inputBuffer.remaining()).order(ByteOrder.nativeOrder())
        val gain = when (boostMb) { 600 -> 1.9952623f; 1200 -> 15.848932f; else -> 1f }
        if (gain == 1f) {
            output.put(inputBuffer) // Original really is bit-for-bit original, including full-scale PCM.
        } else {
            inputBuffer.order(ByteOrder.nativeOrder())
            while (inputBuffer.remaining() >= 2) {
                val amplified = inputBuffer.short / 32768f * gain
                val magnitude = abs(amplified)
                // Continuous soft knee: raise quiet dialogue without wrapping or hard-clipping peaks.
                val limited = if (magnitude <= 0.8f) magnitude else {
                    val excess = magnitude - 0.8f
                    0.8f + 0.2f * (excess / (excess + 0.2f))
                }
                val signed = if (amplified < 0) -limited else limited
                output.putShort((signed * 32768f).roundToInt().coerceIn(-32768, 32767).toShort())
            }
        }
        output.flip()
    }
}
