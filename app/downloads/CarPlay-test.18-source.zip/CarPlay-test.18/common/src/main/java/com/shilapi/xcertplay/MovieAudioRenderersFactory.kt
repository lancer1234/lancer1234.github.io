package com.shilapi.xcertplay

import android.content.Context
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioOffloadSupport
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink

/** Decode movies to PCM so neither HDMI passthrough nor offload bypasses the volume processor. */
@UnstableApi
internal class MovieAudioRenderersFactory(context: Context, private val volume: MovieVolumeProcessor) :
    DefaultRenderersFactory(context) {
    override fun buildAudioSink(context: Context, enableFloatOutput: Boolean,
        enableAudioOutputPlaybackParameters: Boolean): AudioSink = movieAudioSink(context, volume)
}

@UnstableApi
internal fun movieAudioSink(context: Context, volume: MovieVolumeProcessor): AudioSink =
    object : ForwardingAudioSink(DefaultAudioSink.Builder(context)
        .setEnableFloatOutput(false)
        .setAudioProcessors(arrayOf(volume))
        .build()) {
        override fun supportsFormat(format: Format): Boolean =
            format.sampleMimeType == MimeTypes.AUDIO_RAW && super.supportsFormat(format)

        override fun getFormatSupport(format: Format): Int =
            if (format.sampleMimeType == MimeTypes.AUDIO_RAW) super.getFormatSupport(format)
            else AudioSink.SINK_FORMAT_UNSUPPORTED

        override fun getFormatOffloadSupport(format: Format): AudioOffloadSupport =
            AudioOffloadSupport.DEFAULT_UNSUPPORTED
    }
