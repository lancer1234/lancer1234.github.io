package com.shilapi.xcertplay

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Foreground fallback for firmware that does not adjust volume through the default Window route. */
internal class PlaybackVolumeKeys {
    private val presses = mutableSetOf<Triple<Int, Int, Int>>()

    fun dispatch(activity: Activity, event: KeyEvent, streamOverride: Int? = null): Boolean {
        if (!isVolumeKey(event.keyCode)) return false
        val key = Triple(event.deviceId, event.keyCode, event.scanCode)
        if (event.action == KeyEvent.ACTION_UP) return presses.remove(key)
        if (event.action != KeyEvent.ACTION_DOWN || event.isCanceled) return false
        val stream = streamOverride ?: stream(AirPlayPersistence.loadMediaAudioChannel(activity), inCall(activity))
        activity.volumeControlStream = stream
        val audio = activity.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        if (audio.isVolumeFixed) return false // The receiver's own amplifier owns the level.
        return try {
            val direction = when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
                KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
                else -> if (event.repeatCount == 0) AudioManager.ADJUST_TOGGLE_MUTE else AudioManager.ADJUST_SAME
            }
            if (stream == AudioManager.USE_DEFAULT_STREAM_TYPE) {
                audio.adjustSuggestedStreamVolume(direction, stream, AudioManager.FLAG_SHOW_UI)
            } else {
                audio.adjustStreamVolume(stream, direction, AudioManager.FLAG_SHOW_UI)
            }
            presses.add(key)
            true
        } catch (error: RuntimeException) {
            android.util.Log.w("CarPlay-Volume", "Volume adjustment unavailable stream=$stream", error)
            false // Keep the system/OEM fallback when adjustment was refused.
        }
    }

    companion object {
        fun isVolumeKey(keyCode: Int): Boolean = keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_MUTE

        fun stream(mediaChannel: Int, calling: Boolean): Int = when {
            calling -> AudioManager.USE_DEFAULT_STREAM_TYPE
            mediaChannel in AudioManager.STREAM_SYSTEM..20 -> mediaChannel
            else -> AudioManager.STREAM_MUSIC
        }

        fun refresh(activity: Activity) {
            activity.volumeControlStream = stream(AirPlayPersistence.loadMediaAudioChannel(activity), inCall(activity))
        }
    }
}
