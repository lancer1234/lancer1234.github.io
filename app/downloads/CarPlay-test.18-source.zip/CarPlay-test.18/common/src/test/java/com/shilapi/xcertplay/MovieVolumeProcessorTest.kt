package com.shilapi.xcertplay

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sin

@UnstableApi
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [27, 28, 35], manifest = Config.NONE)
class MovieVolumeProcessorTest {
    private fun processor(channels: Int = 2) = MovieVolumeProcessor().apply {
        configure(AudioProcessor.AudioFormat(48000, channels, C.ENCODING_PCM_16BIT))
        flush()
    }
    private fun process(p: MovieVolumeProcessor, pcm: ShortArray): ShortArray {
        val input = ByteBuffer.allocateDirect(pcm.size * 2).order(ByteOrder.nativeOrder())
        pcm.forEach { input.putShort(it) }; input.flip()
        p.queueInput(input)
        assertFalse("Every sample must be consumed", input.hasRemaining())
        val output = p.output.order(ByteOrder.nativeOrder())
        return ShortArray(output.remaining() / 2) { output.short }
    }
    @Test fun originalPreservesEverySampleIncludingFullScale() {
        val p = processor().apply { boostMb = 0 }
        val pcm = shortArrayOf(-32768, 32767, -1234, 1234, 0, 1)
        assertArrayEquals(pcm, process(p, pcm))
    }
    @Test fun quietDialogueHasMeasurableGainAndStrongExceedsOldTwelveDb() {
        val p = processor()
        val pcm = ShortArray(960) { (1000 * sin(it * 0.13)).toInt().toShort() }
        fun rms(a: ShortArray) = kotlin.math.sqrt(a.sumOf { it.toDouble() * it } / a.size)
        p.boostMb = 600
        assertEquals(1.995, rms(process(p, pcm)) / rms(pcm), 0.01)
        p.boostMb = 1200
        assertEquals(15.849, rms(process(p, pcm)) / rms(pcm), 0.02)
    }
    @Test fun fullScalePeaksNeverWrapOrChangePolarity() {
        val p = processor().apply { boostMb = 1200 }
        val pcm = shortArrayOf(-32768, -32000, -12000, -100, 0, 100, 12000, 32000, 32767)
        val result = process(p, pcm)
        assertEquals(pcm.size, result.size)
        for (i in pcm.indices) {
            if (pcm[i] > 0) assertTrue(result[i] > 0)
            if (pcm[i] < 0) assertTrue(result[i] < 0)
            assertTrue(abs(result[i].toInt()) <= 32767)
            if (i > 0) assertTrue(result[i] >= result[i-1])
        }
    }
    @Test fun choicesChangeDuringPlaybackWithoutReconfigureAndKeepChannelsInOrder() {
        val p = processor(6)
        val pcm = shortArrayOf(100, -100, 200, -200, 0, 300)
        p.boostMb = 0; assertArrayEquals(pcm, process(p, pcm))
        p.boostMb = 1200
        val boosted = process(p, pcm)
        assertEquals(1585, boosted[0].toInt())
        assertEquals(-1585, boosted[1].toInt())
        assertEquals(0, boosted[4].toInt())
        p.boostMb = 0; assertArrayEquals(pcm, process(p, pcm))
        p.queueEndOfStream(); assertTrue(p.isEnded)
        p.flush(); assertArrayEquals(pcm, process(p, pcm))
    }
    @Test fun compressedPassthroughAndOffloadCannotSkipTheProcessor() {
        val sink = movieAudioSink(RuntimeEnvironment.getApplication(), processor())
        try {
            for (mime in listOf(MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_AC3, MimeTypes.AUDIO_E_AC3)) {
                val format = Format.Builder().setSampleMimeType(mime).setSampleRate(48000).setChannelCount(2).build()
                assertFalse(sink.supportsFormat(format))
                assertEquals(AudioSink.SINK_FORMAT_UNSUPPORTED, sink.getFormatSupport(format))
                assertFalse(sink.getFormatOffloadSupport(format).isFormatSupported)
            }
            val raw = Format.Builder().setSampleMimeType(MimeTypes.AUDIO_RAW).setPcmEncoding(C.ENCODING_PCM_16BIT)
                .setSampleRate(48000).setChannelCount(2).build()
            assertTrue(sink.supportsFormat(raw))
        } finally { sink.release() }
    }
}
