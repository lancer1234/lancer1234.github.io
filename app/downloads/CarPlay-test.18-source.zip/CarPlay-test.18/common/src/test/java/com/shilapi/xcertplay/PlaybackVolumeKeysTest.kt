package com.shilapi.xcertplay

import android.app.Activity
import android.content.Context
import org.robolectric.annotation.Implements
import org.robolectric.annotation.Implementation
import org.robolectric.shadows.ShadowAudioManager
import android.media.AudioManager
import android.view.KeyEvent
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [27, 28, 35], shadows = [PlaybackVolumeKeysTest.VolumeAudio::class])
class PlaybackVolumeKeysTest {
    @Test fun foregroundUsesMusicAndRefreshesWhenOutputSettingChanges() {
        val controller = Robolectric.buildActivity(Activity::class.java).setup()
        val activity = controller.get()
        try {
            AirPlayPersistence.saveMediaAudioChannel(activity, 0)
            PlaybackVolumeKeys.refresh(activity)
            assertEquals(AudioManager.STREAM_MUSIC, activity.volumeControlStream)
            AirPlayPersistence.saveMediaAudioChannel(activity, AudioManager.STREAM_ALARM)
            PlaybackVolumeKeys.refresh(activity)
            assertEquals(AudioManager.STREAM_ALARM, activity.volumeControlStream)
            AirPlayPersistence.saveMediaAudioChannel(activity, 14)
            PlaybackVolumeKeys.refresh(activity)
            assertEquals(14, activity.volumeControlStream)
        } finally { AirPlayPersistence.saveMediaAudioChannel(activity, 0); controller.pause().stop().destroy() }
    }
    @Test fun callsKeepSystemCallVolumeRoutingInsteadOfForcingMusic() {
        assertEquals(AudioManager.USE_DEFAULT_STREAM_TYPE, PlaybackVolumeKeys.stream(3, true))
        assertEquals(AudioManager.STREAM_MUSIC, PlaybackVolumeKeys.stream(0, false))
    }
    @Test fun projectionSettingsAndMovieWindowsHandlePressHoldAndReleaseOnce() {
        for (type in listOf(CarPlayHostActivity::class.java, DiPlayActivity::class.java, CarPlayVideoActivity::class.java)) {
            val activity = Robolectric.buildActivity(type).get()
            val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, 3, 0)
            VolumeAudio.calls.clear()
            assertTrue(activity.dispatchKeyEvent(KeyEvent(10, 10, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_UP, 0)))
            assertTrue(activity.dispatchKeyEvent(KeyEvent(10, 20, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_UP, 1)))
            assertTrue(activity.dispatchKeyEvent(KeyEvent(10, 30, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_VOLUME_UP, 0)))
            assertEquals("Must not double-adjust on release: $type", 2, VolumeAudio.calls.size)
            assertEquals(5, audio.getStreamVolume(AudioManager.STREAM_MUSIC))
            assertTrue(VolumeAudio.calls.all { it.third and AudioManager.FLAG_SHOW_UI != 0 })
        }
    }

    @Test fun rejectedAdjustmentAndUnpairedReleaseStayWithSystem() {
        val activity = Robolectric.buildActivity(Activity::class.java).get()
        val keys = PlaybackVolumeKeys()
        val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        VolumeAudio.fixed = true
        try {
            assertFalse(keys.dispatch(activity, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_UP)))
            assertFalse(keys.dispatch(activity, KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_VOLUME_UP)))
        } finally { VolumeAudio.fixed = false }
        assertFalse(keys.dispatch(activity, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT)))
    }

    @Implements(AudioManager::class)
    class VolumeAudio : ShadowAudioManager() {
        companion object { val calls = mutableListOf<Triple<Int, Int, Int>>(); var fixed = false }
        @Implementation fun isVolumeFixed(): Boolean = fixed
        @Implementation override fun adjustStreamVolume(streamType: Int, direction: Int, flags: Int) {
            calls.add(Triple(streamType, direction, flags))
            super.adjustStreamVolume(streamType, direction, flags)
        }
    }
}
