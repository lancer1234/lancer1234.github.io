package com.shilapi.xcertplay

import android.content.Context
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class CarPlayVideoSettingsTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()

    @Before fun reset() {
        context.getSharedPreferences("diplay_video", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test fun unknownGearDoesNotEnableVideoByDefault() {
        assertFalse(CarPlayVideoSettings.standaloneEnabled(context))
        assertNull(CarPlayVideoSettings.parked(context, null))
    }

    @Test fun explicitStationaryModeOffersVideoWithoutVehicleIntegration() {
        CarPlayVideoSettings.setStandaloneEnabled(context, true)
        assertTrue(CarPlayVideoSettings.offered(context))
        assertEquals(true, CarPlayVideoSettings.parked(context, null))
        CarPlayVideoSettings.setStandaloneEnabled(context, false)
        assertNull(CarPlayVideoSettings.parked(context, null))
    }

    @Test fun actualGearAlwaysTakesPrecedence() {
        CarPlayVideoSettings.setStandaloneEnabled(context, true)
        assertEquals(false, CarPlayVideoSettings.parked(context, false))
        assertEquals(true, CarPlayVideoSettings.parked(context, true))
    }
}
