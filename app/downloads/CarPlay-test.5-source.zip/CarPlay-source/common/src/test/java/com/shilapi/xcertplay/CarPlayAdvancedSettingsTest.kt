package com.shilapi.xcertplay

import android.widget.LinearLayout
import android.widget.Switch
import android.view.View
import android.view.ViewGroup
import com.shilapi.xcertplay.airplay.AirPlayConfig
import com.shilapi.xcertplay.airplay.AirPlayDisplayConfig
import com.shilapi.xcertplay.airplay.AirPlayInfoPlist
import com.shilapi.xcertplay.host.R
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 33], manifest = Config.NONE, qualifiers = "en")
class CarPlayAdvancedSettingsTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private fun config(microphone: Boolean = true) = AirPlayConfig(
        deviceName = "test", deviceId = "02:00:00:00:00:02", btMac = "02:00:00:00:00:02",
        sourceVersion = "366.0", main = AirPlayDisplayConfig(1920, 1080), microphone = microphone,
    )

    @Before fun reset() {
        app.getSharedPreferences("diplay_carplay_advanced", 0).edit().clear().commit()
    }

    @Test fun displayOnlyRemovesAudioNegotiationAndRestoresUserMicrophoneChoice() {
        assertFalse(CarPlayAdvancedSettings.displayOnly(app))
        CarPlayAdvancedSettings.setDisplayOnly(app, true)
        val silent = CarPlayAdvancedSettings.apply(app, config())
        assertTrue(silent.disableAudioOutput)
        assertFalse(silent.microphone)
        val info = AirPlayInfoPlist.build(silent)
        assertFalse(info.containsKey("audioFormats"))
        assertFalse(info.containsKey("audioLatencies"))
        val resources = (info["modes"] as Map<*, *>)["resources"] as List<*>
        assertEquals(listOf(1), resources.map { (it as Map<*, *>)["resourceID"] })
        CarPlayAdvancedSettings.setDisplayOnly(app, false)
        val restored = CarPlayAdvancedSettings.apply(app, config())
        assertFalse(restored.disableAudioOutput)
        assertTrue(restored.microphone)
        assertNotNull(AirPlayInfoPlist.build(restored)["audioFormats"])
    }

    @Test fun microphoneSwitchCannotInventPermissionOrOverrideAnOptOut() {
        assertFalse(CarPlayAdvancedSettings.apply(app, config(false)).microphone)
        CarPlayAdvancedSettings.setMicrophoneEnabled(app, false)
        assertFalse(CarPlayAdvancedSettings.apply(app, config()).microphone)
        CarPlayAdvancedSettings.setDisplayOnly(app, true)
        CarPlayAdvancedSettings.setDisplayOnly(app, false)
        assertFalse(CarPlayAdvancedSettings.microphoneEnabled(app))
    }

    @Test fun settingsSwitchSavesChoiceAndDisablesReceiverMicrophoneControl() {
        val activity = Robolectric.buildActivity(DiPlayActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        val content = LinearLayout(activity)
        DiPlayActivity::class.java.getDeclaredMethod("advancedCarPlaySettings", LinearLayout::class.java)
            .apply { isAccessible = true }.invoke(activity, content)
        val controls = descendants(content).filterIsInstance<Switch>()
        val displayOnly = controls.single { it.contentDescription == activity.getString(R.string.carplay_display_only) }
        val microphone = controls.single { it.contentDescription == activity.getString(R.string.carplay_microphone) }
        assertTrue(microphone.isEnabled)
        displayOnly.isChecked = true
        assertTrue(CarPlayAdvancedSettings.displayOnly(activity))
        assertFalse(microphone.isEnabled)
        assertTrue(microphone.isChecked)
        displayOnly.isChecked = false
        assertTrue(microphone.isEnabled)
        microphone.isChecked = false
        assertFalse(CarPlayAdvancedSettings.microphoneEnabled(activity))
    }

    @Test fun landscapeSettingIsOptionalAndAppliesToHostOnResume() {
        val activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        assertFalse(CarPlayAdvancedSettings.landscapeLocked(activity))
        CarPlayAdvancedSettings.applyOrientation(activity)
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR, activity.requestedOrientation)
        CarPlayAdvancedSettings.setLandscapeLocked(activity, true)
        CarPlayAdvancedSettings.applyOrientation(activity)
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, activity.requestedOrientation)
        CarPlayAdvancedSettings.setLandscapeLocked(activity, false)
        CarPlayAdvancedSettings.applyOrientation(activity)
        assertEquals(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR, activity.requestedOrientation)
    }

    @Test fun landscapeSwitchSavesTheChoiceWithoutChangingOtherOptions() {
        val activity = Robolectric.buildActivity(DiPlayActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        val content = LinearLayout(activity)
        DiPlayActivity::class.java.getDeclaredMethod("advancedCarPlaySettings", LinearLayout::class.java)
            .apply { isAccessible = true }.invoke(activity, content)
        val lock = descendants(content).filterIsInstance<Switch>().single {
            it.contentDescription == activity.getString(R.string.carplay_landscape_lock)
        }
        assertFalse(lock.isChecked)
        lock.isChecked = true
        assertTrue(CarPlayAdvancedSettings.landscapeLocked(activity))
        assertFalse(CarPlayAdvancedSettings.displayOnly(activity))
        assertTrue(CarPlayAdvancedSettings.microphoneEnabled(activity))
        lock.isChecked = false
        assertFalse(CarPlayAdvancedSettings.landscapeLocked(activity))
    }

    @Test fun speechCompatibilitySwitchPersistsAndIsDisabledInDisplayOnlyMode() {
        val activity = Robolectric.buildActivity(DiPlayActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        val content = LinearLayout(activity)
        DiPlayActivity::class.java.getDeclaredMethod("advancedCarPlaySettings", LinearLayout::class.java)
            .apply { isAccessible = true }.invoke(activity, content)
        val controls = descendants(content).filterIsInstance<Switch>()
        val compatibility = controls.single { it.contentDescription == activity.getString(R.string.carplay_microphone_compatibility) }
        val displayOnly = controls.single { it.contentDescription == activity.getString(R.string.carplay_display_only) }
        assertFalse(compatibility.isChecked)
        compatibility.isChecked = true
        assertTrue(CarPlayAdvancedSettings.speechMicrophoneCompatibility(activity))
        displayOnly.isChecked = true
        assertFalse(compatibility.isEnabled)
        assertTrue(compatibility.isChecked)
        displayOnly.isChecked = false
        assertTrue(compatibility.isEnabled)
    }

    @Test fun microphoneVolumeDefaultsToOriginalAndBoundsSavedValues() {
        assertEquals(0, CarPlayAdvancedSettings.microphoneVolumeLevel(app))
        CarPlayAdvancedSettings.setMicrophoneVolumeLevel(app, 1)
        assertEquals(1, CarPlayAdvancedSettings.microphoneVolumeLevel(app))
        CarPlayAdvancedSettings.setMicrophoneVolumeLevel(app, 100)
        assertEquals(2, CarPlayAdvancedSettings.microphoneVolumeLevel(app))
        CarPlayAdvancedSettings.setMicrophoneVolumeLevel(app, -1)
        assertEquals(0, CarPlayAdvancedSettings.microphoneVolumeLevel(app))
    }

    private fun descendants(view: View): List<View> = listOf(view) +
        if (view is ViewGroup) (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
}
