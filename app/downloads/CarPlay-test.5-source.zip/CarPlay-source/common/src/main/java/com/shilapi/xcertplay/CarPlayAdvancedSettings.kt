package com.shilapi.xcertplay

import android.content.Context
import com.shilapi.xcertplay.airplay.AirPlayConfig

/** Receiver options owned by DiPlay settings; a new session advertises the saved choices. */
internal object CarPlayAdvancedSettings {
    private const val PREFS = "diplay_carplay_advanced"

    fun landscapeLocked(context: Context): Boolean = prefs(context).getBoolean("landscape_locked", false)
    fun setLandscapeLocked(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("landscape_locked", value).apply()

    fun applyOrientation(activity: android.app.Activity) {
        val orientation = if (landscapeLocked(activity))
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        if (activity.requestedOrientation != orientation) activity.requestedOrientation = orientation
    }

    fun displayOnly(context: Context): Boolean = prefs(context).getBoolean("display_only", false)
    fun setDisplayOnly(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("display_only", value).apply()

    fun microphoneEnabled(context: Context): Boolean = prefs(context).getBoolean("microphone_enabled", true)
    fun setMicrophoneEnabled(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("microphone_enabled", value).apply()

    fun speechMicrophoneCompatibility(context: Context): Boolean =
        prefs(context).getBoolean("speech_microphone_compatibility", false)
    fun setSpeechMicrophoneCompatibility(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("speech_microphone_compatibility", value).apply()

    fun microphoneVolumeLevel(context: Context): Int =
        prefs(context).getInt("microphone_volume_level", 0).coerceIn(0, 2)
    fun setMicrophoneVolumeLevel(context: Context, value: Int) =
        prefs(context).edit().putInt("microphone_volume_level", value.coerceIn(0, 2)).apply()

    fun microphoneAllowed(context: Context): Boolean = microphoneEnabled(context) && !displayOnly(context)

    fun apply(context: Context, config: AirPlayConfig): AirPlayConfig = config.copy(
        disableAudioOutput = displayOnly(context),
        microphone = config.microphone && microphoneAllowed(context),
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
