Upstream: https://github.com/xiph/opus
Version: v1.5.2
Commit: ddbe48383984d56acd9e1ab6a090c54ca6b735a6
License: COPYING (BSD). Portable floating point build, no optional DNN.
