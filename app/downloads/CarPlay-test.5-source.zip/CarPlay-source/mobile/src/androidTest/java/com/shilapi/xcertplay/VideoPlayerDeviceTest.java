package com.shilapi.xcertplay;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.lang.reflect.Field;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.Assert.*;

/** Runs the actual app activity and its data-source factory on a connected device.
 * Media is synthetic and served locally over USB; no phone content or internet is used. */
@RunWith(AndroidJUnit4.class)
public class VideoPlayerDeviceTest {
    @Test public void actualPlayerRendersMp4HlsAndAes128HlsWithoutInternet() throws Exception {
        verify("plain.mp4", false);
        verify("hls/playlist.m3u8", true);
        verify("encrypted/playlist.m3u8", true);
    }

    private void verify(String path, boolean streaming) throws Exception {
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        Class<?> bridge = Class.forName("com.shilapi.xcertplay.CarPlayVideo");
        Field url = bridge.getDeclaredField("url"); url.setAccessible(true);
        Field hls = bridge.getDeclaredField("streaming"); hls.setAccessible(true);
        Field playing = bridge.getDeclaredField("playing"); playing.setAccessible(true);
        Field start = bridge.getDeclaredField("startMillis"); start.setAccessible(true);
        url.set(null, "http://127.0.0.1:18765/" + path);
        hls.setBoolean(null, streaming); playing.setBoolean(null, false); start.setInt(null, 0);
        Intent intent = new Intent(instrumentation.getTargetContext(), CarPlayVideoActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Activity activity = instrumentation.startActivitySync(intent);
        Field field = CarPlayVideoActivity.class.getDeclaredField("player"); field.setAccessible(true);
        ExoPlayer player = (ExoPlayer) field.get(activity);
        CountDownLatch firstFrame = new CountDownLatch(1);
        AtomicReference<PlaybackException> error = new AtomicReference<>();
        try {
            instrumentation.runOnMainSync(() -> {
                player.addListener(new Player.Listener() {
                    @Override public void onRenderedFirstFrame() { firstFrame.countDown(); }
                    @Override public void onPlayerError(PlaybackException failure) { error.set(failure); firstFrame.countDown(); }
                });
                player.setVolume(0); player.setPlayWhenReady(true);
            });
            assertTrue("Video frame timed out: " + path, firstFrame.await(25, TimeUnit.SECONDS));
            assertNull("Playback failed: " + path, error.get());
            SystemClock.sleep(1200);
            instrumentation.runOnMainSync(() -> {
                assertTrue("No video size", player.getVideoSize().width > 0);
                assertTrue("Position did not advance", player.getCurrentPosition() > 500);
                assertNotNull("No audio decoder output", player.getAudioFormat());
                Log.i("CarPlay-PlayerTest", "PASS " + path + " width=" + player.getVideoSize().width
                    + " height=" + player.getVideoSize().height + " positionMs=" + player.getCurrentPosition()
                    + " audio=" + player.getAudioFormat().sampleMimeType);
            });
        } finally {
            instrumentation.runOnMainSync(activity::finish);
            instrumentation.waitForIdleSync();
            url.set(null, null); hls.setBoolean(null, false); playing.setBoolean(null, false);
        }
    }
}
